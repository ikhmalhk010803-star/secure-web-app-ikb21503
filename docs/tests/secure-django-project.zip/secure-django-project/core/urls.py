from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    # Authentication
    path('login/', views.UserLoginView.as_view(), name='login'),
    path('logout/', views.UserLogoutView.as_view(), name='logout'),
    path('register/', views.register, name='register'),

    # Functional modules
    path('profile/', views.profile, name='profile'),
    path('add/', views.add_item, name='add_item'),
    path('items/', views.item_list, name='item_list'),
    path('items/update/<int:id>/', views.update_item, name='update_item'),
    path('items/delete/<int:id>/', views.delete_item, name='delete_item'),



    # RBAC / Admin only
    path('admin-only/', views.admin_page, name='admin_page'),
    path('audit-log/', views.audit_log, name='audit_log'),
]

