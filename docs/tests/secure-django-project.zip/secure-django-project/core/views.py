from django.shortcuts import render, redirect
from .forms import ItemForm
from .models import Item
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import UserCreationForm

# -----------------------
# CRUD – Add Item
# -----------------------
@login_required
def add_item(request):
    if request.method == 'POST':
        form = ItemForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_item')
    else:
        form = ItemForm()

    return render(request, 'add_item.html', {'form': form})

# -----------------------
# READ – View Inventory
# -----------------------
@login_required
def item_list(request):
    items = Item.objects.all()

    return render(request, 'item_list.html', {'items': items})

# -----------------------
# UPDATE – Edit Item
# -----------------------
@login_required
def update_item(request, id):
    item = Item.objects.get(id=id)

    if request.method == 'POST':
        form = ItemForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('item_list')
    else:
        form = ItemForm(instance=item)

    return render(request, 'update_item.html', {'form': form})

# -----------------------
# DELETE – Remove Item
# -----------------------
@login_required
def delete_item(request, id):
    item = Item.objects.get(id=id)

    if request.method == 'POST':
        item.delete()
        return redirect('item_list')

    return render(request, 'delete_item.html', {'item': item})


# -----------------------
# Home Page
# -----------------------
def home(request):
    return render(request, 'home.html')


# -----------------------
# Authentication
# -----------------------
class UserLoginView(LoginView):
    template_name = 'login.html'


class UserLogoutView(LogoutView):
    next_page = 'login'


# -----------------------
# Admin-only Page (RBAC)
# -----------------------
@login_required
@user_passes_test(lambda u: u.is_staff)
def admin_page(request):
    return render(request, 'admin.html')



# -----------------------
# 1️⃣ User Profile Page
# -----------------------
@login_required
def profile(request):
    return render(request, 'profile.html')


# -----------------------
# 2️⃣ Audit Log Page (Admin Only)
# -----------------------
@login_required
@user_passes_test(lambda u: u.is_staff)
def audit_log(request):
    logs = [
        "Admin logged in",
        "Admin accessed audit log page",
        "Database migration executed",
    ]
    return render(request, 'audit_log.html', {'logs': logs})



def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()   # password auto hash
            return redirect('login')
    else:
        form = UserCreationForm()

    return render(request, 'register.html', {'form': form})
